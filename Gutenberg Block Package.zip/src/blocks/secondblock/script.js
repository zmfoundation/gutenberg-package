import './style.scss';


import $ from "jquery";

$(document).ready(function(){
    $('.wp-block-wt-block-secondblock').on('click', function(){
        alert(true);
    })
})