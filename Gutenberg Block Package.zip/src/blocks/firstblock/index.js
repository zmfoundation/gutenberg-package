const { registerBlockType } = wp.blocks;
const { __ } = wp.i18n;
const el = wp.element.createElement;

registerBlockType('wt-block/firstblock', {
	title: __('First Block'),
	icon: 'book-alt',
	description: __('First Gutenberg Block'),
	category: 'common',
	edit: function(){
		return "Editor Function";
	},
	save: function(){
		return "Save Function";
	}
} )
