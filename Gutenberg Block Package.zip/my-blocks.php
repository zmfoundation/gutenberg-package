<?php

/**
 * Plugin name: My Block
 * Author: WebTion
 * Description: Simple block
 * Version: 1.0.0
 */

if (! defined('ABSPATH')) {
	exit();
}
 
 /**
  * my_block_register_blocks
  *
  * @param  mixed $block_name
  * @param  mixed $options
  * @return void
  */
  
 function my_block_register_blocks($block_name, $options= array()){
	register_block_type(
		'wt-block/' . $block_name,
		array_merge(
			array(
				'editor_script' => 'blocks-script',
				'editor_style'  => 'blocks-style',
				'script'        => 'blocks-front-script',
				'style'         => 'blocks-front-style'
			),
			$options
		)
	);
 }

/**
 * wt_blocks
 *
 * @return void
 */
function wt_blocks(){
	/**
	 * Blocks Scripts
	 */
	wp_register_script( 'blocks-script', plugins_url( 'dist/editor.js', __FILE__ ), array( 'wp-blocks','wp-i18n' ));

	// Front End Script 
	wp_register_script( 'blocks-front-script', plugins_url( 'dist/script.js', __FILE__ ), array('jquery'));


	wp_register_style( 'blocks-style', plugins_url( 'dist/editor.css', __FILE__ ), array( 'wp-edit-blocks' ));

	// Front End Style
	wp_register_style( 'blocks-front-style', plugins_url( 'dist/style.css', __FILE__ ), array());

	/**
	 * Blocks Registration 
	 */
	my_block_register_blocks('firstblock');
	my_block_register_blocks('secondblock');

}
add_action( 'init', 'wt_blocks' );


